<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\ProjectMaster */

$this->title = Yii::t('app', 'Create Project Master');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Project Masters'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="project-master-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'project_category'=>$project_category,
        'project_status'=>$project_status,
    ]) ?>

</div>
