<?php

/* @var $this yii\web\View */

$this->title = 'AMS';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Welocome to Apartment Management System</h1>
    </div>

            </div>
        </div>

    </div>
</div>
