<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\ProjectTask */

$this->title = Yii::t('app', 'Create Project Task');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Project Tasks'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="project-task-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'task_category'=>$task_category,
        'task_status'=>$task_status,
    ]) ?>

</div>
