<?php

use yii\helpers\Html;

use yii\widgets\ActiveForm;
use dosamigos\datepicker\DatePicker;
use app\models\ProjectName;
use app\models\TaskStatus;
use app\models\TaskCategory;
use yii\helpers\ArrayHelper;

$type_data =Yii::$app->db->createCommand("SELECT DISTINCT (task_category) as task_category from task_category where 'task_category'  IS NOT NULL and task_category !=''")->queryAll();
$type_data = ArrayHelper::map($type_data,'task_category','task_category');
$task_status_data =Yii::$app->db->createCommand("SELECT DISTINCT (task_status) as task_status from task_status where 'task_status'  IS NOT NULL and task_status !=''")->queryAll();
$task_status_data = ArrayHelper::map($task_status_data,'task_status','task_status');

/* @var $this yii\web\View */
/* @var $model app\models\ProjectTask */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="project-task-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'task_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'project_name')->textInput(['maxlength' => true]) ?>
    
    <?= $form->field($task_category, 'task_category')->dropDownList(
        $type_data,
        ['prompt'=>'Select Category...']
        );
        ?>

     <?= $form->field($task_status, 'task_status')->dropDownList(
        $task_status_data,
        ['prompt'=>'Select Status...']
        );
        ?>
  


    <?= $form->field($model, 'deadline')->widget(
    DatePicker::className(), [
        // inline too, not bad
         'inline' => false, 
         // modify template for custom rendering
        //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
        'clientOptions' => [
            'autoclose' => true,
            'format' => 'yyyy-mm-dd'
        ]
]);?>

 

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
