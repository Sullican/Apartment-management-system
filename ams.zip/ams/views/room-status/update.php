<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\RoomStatus */

$this->title = 'Update Room Status: ' . $model->room_status_id;
$this->params['breadcrumbs'][] = ['label' => 'Room Statuses', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->room_status_id, 'url' => ['view', 'id' => $model->room_status_id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="room-status-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
