<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\RoomStatus */

$this->title = 'Create Room Status';
$this->params['breadcrumbs'][] = ['label' => 'Room Statuses', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="room-status-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
