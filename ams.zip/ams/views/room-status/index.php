<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\RoomStatusSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Room Statuses';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="room-status-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Room Status', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'room_status_id',
            'room_status',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
