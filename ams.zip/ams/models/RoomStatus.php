<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "room_status".
 *
 * @property int $room_status_id
 * @property string|null $room_status
 */
class RoomStatus extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'room_status';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['room_status'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'room_status_id' => 'Room Status ID',
            'room_status' => 'Room Status',
        ];
    }
}
