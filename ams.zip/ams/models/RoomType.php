<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "room_type".
 *
 * @property int $room_type_id
 * @property string|null $room_type
 */
class RoomType extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'room_type';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['room_type'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'room_type_id' => 'Room Type ID',
            'room_type' => 'Room Type',
        ];
    }
}
