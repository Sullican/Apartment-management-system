<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "project_task".
 *
 * @property int $task_id
 * @property string $task_name
 * @property int $project_id
 * @property string $project_name
 * @property int $task_status_id
 * @property string $task_status
 * @property int $task_category_id
 * @property string $task_category
 * @property string|null $deadline
 * @property string|null $created_date
 * @property string|null $updated_date
 */
class ProjectTask extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'project_task';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['task_name','project_name', 'task_category', 'task_status'], 'required'],
            [['deadline'], 'safe'],
            [['task_name', 'project_name','task_category', 'task_status'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'task_id' => Yii::t('app', 'Task ID'),
            'task_name' => Yii::t('app', 'Task Name'),
            'project_id' => Yii::t('app', 'Project ID'),
            'project_name' => Yii::t('app', 'Project Name'),
            'task_category_id' => Yii::t('app', 'Task Category ID'),
            'task_category' => Yii::t('app', 'Task Category'),
            'task_status_id' => Yii::t('app', 'Task Status ID'),
            'task_status' => Yii::t('app', 'Task Status'),
            'deadline' => Yii::t('app', 'Deadline'),
            'created_date' => Yii::t('app', 'Created Date'),
            'updated_date' => Yii::t('app', 'Updated Date'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }
     public function beforeSave($insert)
    {
       if (parent::beforeSave($insert))
       {
          if ($this->isNewRecord)
          {
            //$this->status='New';
            $this->created_date =  date('Y-m-d');
            $this->created_by = Yii::$app->user->id;  
          
            
          }
          else
          {
            $this->updated_date =  date('Y-m-d ');
            $this->updated_by = Yii::$app->user->id;  
           
          }
          return true; 
       }
       else 
       {
          return false;
       }              
    }
}
