<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "project_category".
 *
 * @property int $project_category_id
 * @property string $project_category
 * @property string|null $created_date
 * @property string|null $updated_date
 */
class ProjectCategory extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'project_category';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['project_category'], 'required'],
            [['created_date', 'updated_date'], 'safe'],
            [['project_category'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'project_category_id' => Yii::t('app', 'Project Category ID'),
            'project_category' => Yii::t('app', 'Project Category'),
            'created_date' => Yii::t('app', 'Created Date'),
            'updated_date' => Yii::t('app', 'Updated Date'),
        ];
    }
}
