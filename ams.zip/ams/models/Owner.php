<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "owner".
 *
 * @property int $owner_id
 * @property string|null $owner_name
 * @property int|null $room_no
 * @property string|null $owner_start_date
 * @property string|null $owner_end_date
 */
class Owner extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'owner';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['room_no'], 'integer'],
            [['owner_start_date', 'owner_end_date'], 'safe'],
            [['owner_name'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'owner_id' => 'Owner ID',
            'owner_name' => 'Owner Name',
            'room_no' => 'Room No',
            'owner_start_date' => 'Owner Start Date',
            'owner_end_date' => 'Owner End Date',
        ];
    }
}
