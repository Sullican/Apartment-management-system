<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "tenant".
 *
 * @property int $tenant_id
 * @property string|null $tenant_name
 * @property int|null $room_no
 * @property string|null $owner_name
 * @property int|null $no_of_residents
 * @property string|null $tenant_start_date
 * @property string|null $tenant_end_date
 */
class Tenant extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tenant';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['room_no', 'no_of_residents'], 'integer'],
            [['tenant_start_date', 'tenant_end_date'], 'safe'],
            [['tenant_name', 'owner_name'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'tenant_id' => 'Tenant ID',
            'tenant_name' => 'Tenant Name',
            'room_no' => 'Room No',
            'owner_name' => 'Owner Name',
            'no_of_residents' => 'No Of Residents',
            'tenant_start_date' => 'Tenant Start Date',
            'tenant_end_date' => 'Tenant End Date',
        ];
    }
}
